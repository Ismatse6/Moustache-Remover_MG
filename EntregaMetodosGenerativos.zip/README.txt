Trabajo de Jorge Carrasco, Iván López e Ismael Perdomo.


La carpeta se encuentr dividida en diferentes partes:

- Memoria del Trabajo

- Presentación

- Archivo .ipynb

- Carpeta repositorio de resultados donde hemos guardado resultados de la UNET y de la GAN así como el código en PDF por si acaso no se guardasen los resultados en el Google Colab.